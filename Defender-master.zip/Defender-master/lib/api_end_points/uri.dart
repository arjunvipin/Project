//import 'package:phish_defender/presentation/Home/Widgets/homescreenwidget.dart';

class Url {
  String baseurl = "http://10.0.2.2:5000/api?query=";
  String tableurl = "http://10.0.2.2:5000/details?query=";
}
// 10.0.2.2