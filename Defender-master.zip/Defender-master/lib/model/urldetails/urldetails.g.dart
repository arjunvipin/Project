// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'urldetails.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Urldetails _$UrldetailsFromJson(Map<String, dynamic> json) => Urldetails(
      tableout: json['tableout'] as List<dynamic>?,
    );

Map<String, dynamic> _$UrldetailsToJson(Urldetails instance) =>
    <String, dynamic>{
      'tableout': instance.tableout,
    };
