import 'package:flutter/material.dart';

const khight = SizedBox(
  height: 10,
);

const kwidht = SizedBox(
  width: 10,
);

String lottieLoadingAnimation = "lib/animations/loaging_animation.json";
