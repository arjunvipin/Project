import 'package:flutter/material.dart';

const kblack = Colors.black;
const kwhite = Colors.white;
const ktransparent = Colors.transparent;
const kgrey = Colors.grey;

const colorizeColors = [
  Colors.cyan,
  Colors.blue,
  Colors.grey,
  Colors.red,
];
