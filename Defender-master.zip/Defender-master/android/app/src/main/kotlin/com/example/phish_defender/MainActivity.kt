package com.example.phish_defender

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
